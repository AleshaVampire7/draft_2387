package DatabaseRepository;

public interface IDatabaseRepository {
}
