package com.company.DatabaseController;

public interface IDatabaseController {
}
