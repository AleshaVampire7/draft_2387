package com.company.Validator;

public interface IValidator {

    public boolean checkPassword(String Password);

}
