package com.company.data;

import java.sql.Connection;

public interface IDBManager  {
    public Connection getConnection();
}
